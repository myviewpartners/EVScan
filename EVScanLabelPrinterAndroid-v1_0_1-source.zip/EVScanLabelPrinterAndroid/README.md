# EV Scan & Label Printer — Native Android WebView Shell

This Android Studio project wraps:

`https://effahsview.com/scan-label-printer/`

It is designed specifically for EV Suite's WebView-first Scan & Label Printer.

## Included native capabilities

- Android runtime CAMERA permission
- WebView `PermissionRequest.RESOURCE_VIDEO_CAPTURE` forwarding
- Camera and gallery support through `onShowFileChooser()`
- Persistent WordPress cookies/login
- HTTPS-only navigation for Effah's View
- External links opened in Android apps/browser
- Android PrintManager integration
- DownloadManager integration
- JavaScript bridge named `EVAndroid`
- App Settings shortcut
- Native back-button handling
- EV branded icon and splash assets

## Build requirements

- Android Studio Ladybug or newer
- JDK 17
- Android SDK 35
- Internet connection during the first Gradle sync

## Build an APK

1. Open this folder in Android Studio.
2. Allow Gradle sync to complete.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will be generated under:
   `app/build/outputs/apk/debug/app-debug.apk`

For a release APK/AAB, use **Build > Generate Signed Bundle / APK** and create or select a signing key.

## Test order

1. Install the APK.
2. Open it and sign in to WordPress.
3. Tap **Open Camera & Scan**.
4. Grant camera permission.
5. Capture a QR/barcode image.
6. Confirm automatic label loading.
7. Test live scanning, Print, and Download.

## Security

Only HTTPS pages on `effahsview.com` and its subdomains remain inside the WebView. Other links open externally. Cleartext HTTP traffic is disabled.
