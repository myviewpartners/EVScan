-keepclassmembers class com.effahsview.scanlabelprinter.MainActivity$NativeBridge {
    @android.webkit.JavascriptInterface <methods>;
}
